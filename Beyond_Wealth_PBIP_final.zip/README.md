# Beyond Wealth — Global Health Analytics

Open **BeyondWealth.pbip** in Power BI Desktop.

## Pages
1. Executive Overview
2. Wealth vs Outcomes
3. Country Explorer
4. Methodology & Sources

The solution contains a PBIR report, TMDL model, Power Query import, DAX measures, source CSV, custom theme, and a bespoke visual background.
